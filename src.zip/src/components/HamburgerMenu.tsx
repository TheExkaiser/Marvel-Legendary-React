import { useState } from 'react'

interface HamburgerMenuProps {
  onMainMenu: () => void
  onRestart: () => void
  onSettings: () => void
  onHistory: () => void
  onKeywords?: () => void
}

export function HamburgerMenu({ onMainMenu, onRestart, onSettings, onHistory, onKeywords }: HamburgerMenuProps) {
  const [open, setOpen] = useState(false)

  return (
    <div className="hamburger-wrap">
      <button className="hamburger-button" onClick={() => setOpen((o) => !o)}>
        ☰
      </button>
      {open && (
        <div className="hamburger-menu">
          <button
            onClick={() => {
              setOpen(false)
              onHistory()
            }}
          >
            Game History
          </button>
          <button
            onClick={() => {
              setOpen(false)
              onSettings()
            }}
          >
            Settings
          </button>
          {onKeywords && (
            <button
              onClick={() => {
                setOpen(false)
                onKeywords()
              }}
            >
              Keywords
            </button>
          )}
          <button
            onClick={() => {
              setOpen(false)
              onMainMenu()
            }}
          >
            Main Menu
          </button>
          <button
            onClick={() => {
              setOpen(false)
              onRestart()
            }}
          >
            Restart
          </button>
        </div>
      )}
    </div>
  )
}