import type { GameState, GameSetup, CardData } from './types'
import type { UiAdapter } from './ui'
import { registerScheme } from './schemeRegistry'
import { registerGameMode } from './gameModeRegistry'
import { buildDeck } from './deck'
import { shuffle } from './random'
import { HAND_SIZE } from './constants'
import { drawCards } from './deckOps'
import { refillHq } from './recruit'
import { villainPhase } from './villainPhase'

/** Dokleja BASE_URL do ścieżki obrazka, tak jak już robimy to dla ikon — żeby działało
 * identycznie lokalnie (BASE_URL='/') i po deployu na GitHub Pages (BASE_URL='/nazwa-repo/').
 * Nie mutuje oryginalnej karty (to singleton z cards.ts, używany w kolejnych grach). */
export function withPrefixedImg(card: CardData): CardData {
  if (!card.img || /^https?:\/\//.test(card.img)) return card
  return { ...card, img: `${import.meta.env.BASE_URL}${card.img.replace(/^\//, '')}` }
}

/** Buduje słownik id -> dane karty ze wszystkich kart użytych w grze. */
function buildCardIndex(setup: GameSetup): Record<string, CardData> {
  const { startingCards, heroCards, villainCards, villainDeckHeroCards, mastermind } = setup

  const allCards: CardData[] = [
    ...[...startingCards, ...heroCards, ...villainCards, ...villainDeckHeroCards].map((e) => e.card),
    setup.officerCards.card,
    ...(setup.sidekickCards ? [setup.sidekickCards.card] : []),
    setup.wounds.card,
    ...setup.bystanders.map((e) => e.card),
    setup.twist,
    setup.masterStrikeCard,
    mastermind.card,
    ...mastermind.tactics,
    ...(mastermind.extraCards ?? []),
    ...(setup.extraMasterminds ?? []).flatMap((m) => [m.card, ...m.tactics, ...(m.extraCards ?? [])]),
  ]

  const cards: Record<string, CardData> = {}
  for (const card of allCards) {
    cards[card.id] = withPrefixedImg(card)
  }

  // Generyczna karta Master Strike dostaje opis efektu aktualnego mastermina
  cards[setup.masterStrikeCard.id] = withPrefixedImg({
    ...setup.masterStrikeCard,
    text: mastermind.masterStrikeText,
  })

  return cards
}

/** Tworzy pełny, gotowy do gry stan (talie potasowane, HQ zapełnione, setup scheme'u wykonany). */
export function createGameState(setup: GameSetup): GameState {
  const { startingCards, heroCards, villainCards, villainDeckHeroCards, mastermind, scheme, gameMode } = setup
  registerScheme(scheme)
  registerGameMode(gameMode)

  // Bystanderzy: część trafia do talii złoczyńców, reszta zostaje w stosie
  const bystanders = shuffle(buildDeck(setup.bystanders))
  const bystandersForVillainDeck = bystanders.splice(0, setup.bystandersInVillainDeck)
  const bystandersForHeroDeck = bystanders.splice(0, setup.bystandersInHeroDeck)

  const twists = buildDeck([{ card: setup.twist, count: scheme.twistCount }])
  const masterStrikes = buildDeck([
    { card: setup.masterStrikeCard, count: setup.masterStrikeCount },
  ])

  const state: GameState = {
    cards: buildCardIndex(setup),

    // Gracz
    deck: shuffle(buildDeck(startingCards)),
    hand: [],
    played: [],
    discard: [],
    cardsPlayedThisTurn: [],
    oncePerTurnAbilitiesUsed: [],

    // Rekrutacja
    heroDeck: shuffle([...buildDeck(heroCards), ...bystandersForHeroDeck]),
    hq: [null, null, null, null, null],
    officerDeck: shuffle(buildDeck([setup.officerCards])),
    officerCardId: setup.officerCards.card.id,
    sidekickStack: setup.sidekickCards ? shuffle(buildDeck([setup.sidekickCards])) : [],
    sidekickCardId: setup.sidekickCards?.card.id,
    sidekicksRecruitedThisTurn: false,

    // Złoczyńcy i miasto
    villainDeck: shuffle([
      ...buildDeck(villainCards),
      ...buildDeck(villainDeckHeroCards),
      ...bystandersForVillainDeck,
      ...twists,
      ...masterStrikes,
    ]),
    city: [null, null, null, null, null],
    cityMarkers: [[], [], [], [], []],
    escaped: [],
    escapedBystanders: [],
    defeated: [],

    // Ranki, bystanderzy, jeńcy, KO
    wounds: buildDeck([setup.wounds]),
    bystanders,
    captives: {},
    attachedCards: {},
    locationAttackModifiers: {},
    bystandersRescuedThisTurn: 0,
    rooftopsKoAvailable: 0,
    rooftopsRescueVpBonus: 0,
    mastermindAttackModifierThisTurn: 0,
    recruitCountsAsAttackThisTurn: false,
    cardsDrawnThisTurn: 0,
    recruitGainedThisTurn: 0,
    pendingSurgeOfPower: 0,
    attackGainedThisTurn: 0,
    ko: [],

    // Mastermind
    mastermind: { instanceId: mastermind.card.id, cardId: mastermind.card.id },
    masterminds: [{ instanceId: mastermind.card.id, cardId: mastermind.card.id }],
    tactics: shuffle(mastermind.tactics.map((t) => ({ instanceId: t.id, cardId: t.id }))),
    mastermindTactics: {},
    mastermindTacticReserve: {},
    extraMasterminds: setup.extraMasterminds,
    extraHenchmenCardIds: setup.extraHenchmenCardIds,
    mastermindStrikeIds: { [mastermind.card.id]: mastermind.masterStrikeId },
    singleFightMasterminds: [],
    defeatedMastermindIds: [],
    mastermindAttackModifiers: {},
    mysterioTacticIds: [],
    masterStrikeId: mastermind.masterStrikeId,
    ledVillainGroup: villainCards.map((e) => e.card.villainGroup).find((g) => g !== undefined),

    // Scheme + Game Mode
    schemeId: scheme.id,
    gameModeId: gameMode.id,
    counters: {},
    twistsRevealed: 0,

    // Tura i zasoby
    log: [],
    attack: 0,
    recruit: 0,
    turn: 1,
    extraTurnsQueued: 0,
    bonusDrawNextTurn: 0,
    status: 'playing',
    debugUsed: false,
    masterStrikeAutoDrawUsedThisTurn: false,
    enemiesCostRecruitThisTurn: false,
    heroesCostAttackThisTurn: false,
  }

  console.log('ledVillainGroup:', state.ledVillainGroup, villainCards.map((e) => [e.card.name, e.card.villainGroup]))
  refillHq(state)
  scheme.setup?.(state)
  return state
}

/** Start gry: pierwsza ręka + pierwsza faza złoczyńcy. */
export async function startGame(state: GameState, ui: UiAdapter): Promise<void> {
  drawCards(state, HAND_SIZE)
  state.cardsDrawnThisTurn = 0 // pierwsza ręka też się nie liczy jako "extra"
  await villainPhase(state, ui)
}
