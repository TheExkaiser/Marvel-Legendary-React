import type { GameState, CardInstance } from './types'
import type { UiAdapter } from './ui'
import { getCardAbility } from './cardAbilities'
import { getVillainAbilities } from './villainAbilities'
import { canDefeatVillain } from './villainRequirements'
import { getEffectiveStrength, koCard } from './keywords'
import { getScheme } from './schemeRegistry'
import { assertPlaying, logEvent } from './common'
import { rescueBystander, rescueCard } from './wounds'
import { addRecruit } from './resources'
import { CITY_NAMES } from './constants'
import { drawCards } from './deckOps'
import { asEnemyEffect } from './replacements'
import { gainVillainAsHero, gainVillainWithHeroSide } from './cardData'
import { refillHq } from './recruit'
import { getMastermindRule } from './mastermindRules'
import { isCityDestroyed } from './cityLayout'
import { claimShardFrom } from './shards'
import { runArtifactReactions } from './artifacts'

/** Czy Recruit płaci za tę kartę jak Attack: God of Thunder (cała tura) albo Bribe (tylko ta karta). */
function recruitPays(state: GameState, cardId: string): boolean {
  return state.recruitCountsAsAttackThisTurn || (state.cards[cardId].keywords ?? []).includes('bribe')
}

const DEMON_GOBLIN_ATTACK = 2

type FightEffectCancellation = (state: GameState, ui: UiAdapter, enemy: CardInstance) => Promise<boolean>
type LocationDefeatHook = (
  state: GameState,
  ui: UiAdapter,
  location: string,
) => Promise<void>
type VillainDefeatHook = (
  state: GameState,
  ui: UiAdapter,
  source: CardInstance,
  villain: CardInstance,
) => Promise<void>

const fightEffectCancellations = new Map<string, FightEffectCancellation>()
const locationDefeatHooks = new Map<string, LocationDefeatHook>()
const villainDefeatHooks = new Map<string, VillainDefeatHook>()

export function registerFightEffectCancellation(cardId: string, callback: FightEffectCancellation): void {
  fightEffectCancellations.set(cardId, callback)
}

export function registerLocationDefeatHook(cardId: string, callback: LocationDefeatHook): void {
  locationDefeatHooks.set(cardId, callback)
}

export function registerVillainDefeatHook(cardId: string, callback: VillainDefeatHook): void {
  villainDefeatHooks.set(cardId, callback)
}

async function resolveLocationDefeatHooks(state: GameState, ui: UiAdapter, location: string): Promise<void> {
  for (const card of state.cardsPlayedThisTurn) {
    await locationDefeatHooks.get(card.cardId)?.(state, ui, location)
  }
}

async function resolveVillainDefeatHooks(
  state: GameState,
  ui: UiAdapter,
  villain: CardInstance,
): Promise<void> {
  if (state.cards[villain.cardId].henchman) {
    state.henchmenDefeatedThisTurn = (state.henchmenDefeatedThisTurn ?? 0) + 1
  }
  for (const card of state.cardsPlayedThisTurn) {
    if (!(state.activeVillainDefeatHooks ?? []).includes(card.instanceId)) continue
    await villainDefeatHooks.get(card.cardId)?.(state, ui, card, villain)
  }
}

function enemiesCostRecruit(state: GameState): boolean {
  return (
    state.enemiesCostRecruitThisTurn ||
    (getScheme(state).id === 'fantasticfour_pull_reality_into_the_negative_zone' &&
      [2, 4, 6].includes(state.twistsRevealed))
  )
}

function availableAttack(state: GameState, cardId: string): number {
  if (enemiesCostRecruit(state)) return state.recruit
  return state.attack + (recruitPays(state, cardId) ? state.recruit : 0)
}

/** Czy gracza stać na walkę z tym Villainem. Te same warunki co w fightVillain, ale bez wykonywania akcji (podświetlanie w UI). */
export function canAffordVillain(state: GameState, villain: CardInstance): boolean {
  if (state.status !== 'playing') return false
  if (!canDefeatVillain(state, villain.cardId)) return false
  const strength = getEffectiveStrength(state, villain) ?? 0
  return availableAttack(state, villain.cardId) >= strength
}

/** Czy gracza stać na walkę z Mastermindem. Te same warunki co w fightMastermind, ale bez wykonywania akcji (podświetlanie w UI).
 * Gdy reguła Mastermina podaje kilka możliwych sił (Galactus: Cosmic Threat), wystarczy, że stać nas na którąkolwiek. */
export function canAffordMastermind(state: GameState): boolean {
  return canAffordMastermindTarget(state, state.mastermind)
}

export function canAffordMastermindTarget(state: GameState, mastermind: CardInstance): boolean {
  if (state.status !== 'playing') return false
  if ((state.defeatedMastermindIds ?? []).includes(mastermind.instanceId)) return false
  const isSingleFight = (state.singleFightMasterminds ?? []).includes(mastermind.instanceId)
  const tactics = mastermind.instanceId === state.mastermind.instanceId
    ? state.tactics
    : state.mastermindTactics?.[mastermind.instanceId] ?? []
  if (!isSingleFight && tactics.length === 0) return false
  const rule = getMastermindRule(state, mastermind)
  if (rule?.canFight && !rule.canFight(state, mastermind)) return false
  const strengths =
    rule?.fightStrengthOptions?.(state) ?? [getEffectiveStrength(state, mastermind) ?? 0]
  const additionalCost = mastermind.instanceId === state.mastermind.instanceId
    ? getScheme(state).mastermindFightAdditionalCost?.(state) ?? 0
    : 0
  const totalAttackOrRecruit = state.attack + state.recruit
  return strengths.some(
    (strength) =>
      availableAttack(state, mastermind.cardId) >= strength &&
      (additionalCost === 0 || totalAttackOrRecruit >= strength + additionalCost),
  )
}

/** Jeńcy-Bystanderzy Mastermina, którzy są Villainami do pokonania (Madelyne: Demon Goblins). undefined, gdy nie ma takich. */
export function captiveVillainInfo(state: GameState): { mastermind: CardInstance; attack: number; count: number } | undefined {
  for (const mastermind of state.masterminds ?? [state.mastermind]) {
    const attack = getMastermindRule(state, mastermind)?.captiveVillainAttack
    if (attack === undefined) continue
    const count = (state.captives[mastermind.instanceId] ?? []).filter((card) => state.cards[card.cardId].kind === 'bystander').length
    if (count > 0) return { mastermind, attack, count }
  }
  return undefined
}

/** Czy gracza stać na jeńca Mastermina (te same warunki co w fightMastermindCaptive). */
export function canAffordMastermindCaptive(state: GameState): boolean {
  if (state.status !== 'playing') return false
  const info = captiveVillainInfo(state)
  if (!info) return false
  const captives = state.captives[info.mastermind.instanceId] ?? []
  const goblin = captives.find((card) => state.cards[card.cardId].kind === 'bystander')
  return !!goblin && availableAttack(state, goblin.cardId) >= info.attack
}

/** Czy gracza stać na Demon Goblina (te same warunki co w fightDemonGoblin). */
export function canAffordDemonGoblin(state: GameState): boolean {
  if (state.status !== 'playing') return false
  const stack = state.demonGoblins ?? []
  const goblin = stack[stack.length - 1]
  return !!goblin && availableAttack(state, goblin.cardId) >= DEMON_GOBLIN_ATTACK
}

async function spendAttack(state: GameState, amount: number, ui: UiAdapter, cardId: string): Promise<void> {
  if (enemiesCostRecruit(state)) {
    state.recruit -= amount
    return
  }

  if (!recruitPays(state, cardId)) {
    state.attack -= amount
    return
  }

  if (state.attack <= 0 || state.recruit <= 0) {
    const fromAttack = Math.min(state.attack, amount)
    state.attack -= fromAttack
    state.recruit -= amount - fromAttack
    return
  }

  const maxFromAttack = Math.min(amount, state.attack)
  const maxFromRecruit = Math.min(amount, state.recruit)
  const { fromAttack, fromRecruit } = await ui.chooseAttackSplit(amount, maxFromAttack, maxFromRecruit)
  state.attack -= fromAttack
  state.recruit -= fromRecruit
}

/** Ultimate Nullifier: gracz może anulować efekt Fight. Pytamy tylko, gdy efekt faktycznie istnieje. */
async function fightEffectCancelled(state: GameState, ui: UiAdapter, enemy: CardInstance): Promise<boolean> {
  if (state.cancelFightEffectsThisTurn) {
    const choice = await ui.chooseOptionWithCard(
      enemy,
      [
        { id: 'cancel', label: 'Cancel the Fight effect (Ultimate Nullifier)' },
        { id: 'resolve', label: 'Resolve the Fight effect' },
      ],
      'Ultimate Nullifier',
    )
    if (choice === 'cancel') return true
  }

  for (const card of state.played) {
    const cancel = fightEffectCancellations.get(card.cardId)
    if (cancel && (await cancel(state, ui, enemy))) return true
  }
  return false
}

/** Villain, który po pokonaniu trafia do discarda gracza zamiast do Victory Pile (Infinity Gems, Ultimate Avengers). */
function goesToDiscard(state: GameState, cardId: string): boolean {
  const keywords = state.cards[cardId].keywords ?? []
  return keywords.includes('villain-artifact') || keywords.includes('villain-hero')
}

/** Kładzie pokonanego Villaina na discardzie gracza. 'villain-hero' zamienia go przy tym w Bohatera. */
function gainToDiscard(state: GameState, villain: CardInstance): void {
  state.discard.push(villain)
  if ((state.cards[villain.cardId].keywords ?? []).includes('villain-hero')) {
    gainVillainWithHeroSide(state, villain)
  }
}

async function removeVillainFromCity(
  state: GameState,
  index: number,
  ui: UiAdapter,
  toDiscard = false,
): Promise<void> {
  const villain = state.city[index]!
  const location = CITY_NAMES[index]
  state.city[index] = null
  claimShardFrom(state, villain) // jeden Shard dla gracza, reszta do zapasu
  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)

  const scheme = getScheme(state)
  const captives = state.captives[villain.instanceId] ?? []
  const rescued = scheme.onCaptivesRescued?.(state, villain, captives) ?? captives
  delete state.captives[villain.instanceId]
  delete state.attachedCards[villain.instanceId]

  // Burrow: bonusy za pokonanie działają, ale Villain wraca do Streets zamiast do Victory Pile (bez Ambush)
  const burrows = state.burrowingVillainId === villain.instanceId
  state.burrowingVillainId = undefined
  const streetsIndex = CITY_NAMES.indexOf('Streets')

  if (burrows && !isCityDestroyed(state, streetsIndex) && state.city[streetsIndex] === null) {
    state.city[streetsIndex] = villain
  } else if (toDiscard) {
    gainToDiscard(state, villain)
  } else if (scheme.onVillainDefeated) {
    scheme.onVillainDefeated(state, villain)
  } else {
    state.defeated.push(villain)
  }
  // Jeńcy uratowani przez pokonanie Villaina: każdy osobno (popup, bonusy "rescue", zdolność Bystandera)
  for (const card of rescued) await rescueCard(state, card, ui)

  // Bonusy za pokonanie Villaina w konkretnych lokacjach (Night Hunter, Nowhere to Hide)
  for (const bonus of state.locationDefeatBonuses ?? []) {
    if (!bonus.locations.includes(location)) continue
    if (bonus.recruit) addRecruit(state, bonus.recruit)
    if (bonus.draw) drawCards(state, bonus.draw)
    for (let i = 0; i < (bonus.rescue ?? 0); i++) await rescueBystander(state, ui)
  }

  if (location === 'Rooftops') {
    if ((state.rooftopsRescueVpBonus ?? 0) > 0) {
      for (let i = 0; i < (state.cards[villain.cardId].vp ?? 0); i++) await rescueBystander(state, ui)
      state.rooftopsRescueVpBonus = Math.max(0, (state.rooftopsRescueVpBonus ?? 0) - 1)
    }
    if ((state.rooftopsKoAvailable ?? 0) > 0) {
      state.rooftopsKoAvailable = Math.max(0, (state.rooftopsKoAvailable ?? 0) - 1)
      const chosen = await ui.choose([...state.hand, ...state.discard], {
        prompt: 'Lunar Communion: możesz KO kartę z ręki lub stosu odrzuconych',
        optional: true,
      })
      if (chosen) koCard(state, chosen.instanceId)
    }
  }
  await resolveLocationDefeatHooks(state, ui, location)
  await resolveVillainDefeatHooks(state, ui, villain)

  if (
    !burrows &&
    state.defeated.some((card) => card.instanceId === villain.instanceId) &&
    rescued.some((card) => state.cards[card.cardId].kind === 'bystander')
  ) {
    const candidates = [villain, ...rescued].filter((card) =>
      state.defeated.some((entry) => entry.instanceId === card.instanceId),
    )
    const remaining = [...candidates]
    const order: CardInstance[] = []
    while (remaining.length > 1) {
      const chosen = await ui.choose(remaining, {
        prompt: 'Choose the order of this Villain and its rescued Bystanders in your Victory Pile',
        optional: false,
      })
      const selected = chosen ?? remaining[0]
      order.push(selected)
      const index = remaining.findIndex((card) => card.instanceId === selected.instanceId)
      remaining.splice(index, 1)
    }
    order.push(...remaining)
    const ids = new Set(order.map((card) => card.instanceId))
    const firstIndex = state.defeated.findIndex((card) => ids.has(card.instanceId))
    state.defeated = state.defeated.filter((card) => !ids.has(card.instanceId))
    state.defeated.splice(firstIndex, 0, ...order)
  }
}

async function resolveVillainFightEffects(
  state: GameState,
  ui: UiAdapter,
  villain: CardInstance,
): Promise<boolean> {
  const data = state.cards[villain.cardId]
  const abilities = getVillainAbilities(villain.cardId)
  const isVillainArtifact = goesToDiscard(state, villain.cardId)
  // Feast is a generic Fight effect. The card may have no additional onFeast
  // hook (for example Demogoblin), but it must still KO the top card.
  if (!abilities?.onFight && !(data.keywords ?? []).includes('feast') && !isVillainArtifact) return true
  if (await fightEffectCancelled(state, ui, villain)) return false

  await asEnemyEffect(state, async () => {
    if ((data.keywords ?? []).includes('feast')) {
      const feasted = state.deck.pop()
      if (feasted) {
        state.ko.push(feasted)
        await ui.revealCard(feasted, `${data.name} feasts on ${state.cards[feasted.cardId].name}`)
        await abilities?.onFeast?.(state, ui, villain, feasted)
      }
    }
    await abilities?.onFight?.(state, ui, villain)
  })
  return true
}

/** Mind Control (Professor X): zdobywasz pokonanego Villaina. Idzie do Twoich odrzuconych jak kupiona karta
 * i działa jak Bohater z Attack równym swojej sile. Działa przy każdym pokonaniu (walka, za darmo, z talii). */
async function offerMindControl(state: GameState, villain: CardInstance, ui: UiAdapter): Promise<void> {
  if (!state.mindControlThisTurn) return

  // Jeśli scheme przejął kartę (onVillainDefeated), nie ma jej w Victory Pile i nie ma czego zdobywać
  const pileIndex = state.defeated.findIndex((c) => c.instanceId === villain.instanceId)
  if (pileIndex === -1) return

  const data = state.cards[villain.cardId]
  const chosen = await ui.choose([villain], {
    prompt: `Mind Control: zdobyć ${data.name} jako Bohatera (+${data.strength ?? 0} Attack)?`,
    optional: true,
  })
  if (!chosen) return

  state.defeated.splice(pileIndex, 1)
  state.discard.push(villain)
  gainVillainAsHero(state, villain)
}

/** Villain z wierzchu talii złoczyńców (Telepathic Probe, Hail of Bullets): zdejmuje go i pokonuje.
 * payAttack = true: płaci Attack (zwraca false, gdy za mało); false: pokonanie za darmo. */
export async function defeatVillainFromDeck(
  state: GameState,
  ui: UiAdapter,
  payAttack: boolean,
): Promise<boolean> {
  assertPlaying(state)
  const villain = state.villainDeck[state.villainDeck.length - 1]
  if (!villain) return false
  if (!canDefeatVillain(state, villain.cardId)) return false

  if (payAttack) {
    const strength = getEffectiveStrength(state, villain) ?? 0
    if (availableAttack(state, villain.cardId) < strength) return false
    await spendAttack(state, strength, ui, villain.cardId)
  }

  state.villainDeck.pop()

  const fightEffectsResolved = await resolveVillainFightEffects(state, ui, villain)
  const toDiscard = fightEffectsResolved && goesToDiscard(state, villain.cardId)
  state.burrowingVillainId = undefined // Villain z talii nie stoi w mieście, więc nie ma gdzie się zakopać

  await runArtifactReactions(state, ui, 'villain-defeated')
  if (toDiscard) claimShardFrom(state, villain)

  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)

  const scheme = getScheme(state)
  if (toDiscard) {
    gainToDiscard(state, villain)
  } else if (scheme.onVillainDefeated) {
    scheme.onVillainDefeated(state, villain)
  } else {
    state.defeated.push(villain)
  }

  await scheme.afterVillainDefeated?.(state, villain, ui)

  logEvent(state, `Defeated from Villain Deck: ${state.cards[villain.cardId].name}`)
  await resolveVillainDefeatHooks(state, ui, villain)
  await offerMindControl(state, villain, ui)
  return true
}

export async function fightVillain(
  state: GameState,
  instanceId: string,
  ui: UiAdapter,
): Promise<void> {
  assertPlaying(state)
  const cityIndex = state.city.findIndex((c) => c?.instanceId === instanceId)
  const hqIndex = state.hq.findIndex((c) => c?.instanceId === instanceId)
  const scheme = getScheme(state)
  const hqCard = hqIndex === -1 ? undefined : state.hq[hqIndex]
  const isHqVillain = cityIndex === -1 && hqIndex !== -1 && scheme.canFightVillainsInHq === true &&
    !!hqCard && (state.cards[hqCard.cardId].villainGroup !== undefined || state.cards[hqCard.cardId].henchman === true)
  if (cityIndex === -1 && !isHqVillain) throw new Error(`Złoczyńcy ${instanceId} nie ma w mieście`)

  const villain = isHqVillain ? state.hq[hqIndex]! : state.city[cityIndex]!
  if (!canDefeatVillain(state, villain.cardId)) {
    throw new Error('Nie możesz teraz pokonać tego złoczyńcy (niespełniony warunek)')
  }

  const strength = getEffectiveStrength(state, villain) ?? 0
  if (availableAttack(state, villain.cardId) < strength) {
    throw new Error(`Za mało attack: masz ${availableAttack(state, villain.cardId)}, siła ${strength}`)
  }

  await spendAttack(state, strength, ui, villain.cardId)

  const fightEffectsResolved = await resolveVillainFightEffects(state, ui, villain)
  const toDiscard = fightEffectsResolved && goesToDiscard(state, villain.cardId)

  if (state.returnVillainToCity?.instanceId === villain.instanceId) {
    const returnIndex = state.returnVillainToCity.cityIndex
    state.returnVillainToCity = undefined
    state.city[returnIndex] = villain
    logEvent(state, `Feast returned: ${state.cards[villain.cardId].name}`)
    return
  }

  await runArtifactReactions(state, ui, 'villain-defeated')

  if (isHqVillain) {
    state.hq[hqIndex] = null
    claimShardFrom(state, villain)
    const captives = state.captives[villain.instanceId] ?? []
    const rescued = scheme.onCaptivesRescued?.(state, villain, captives) ?? captives
    delete state.captives[villain.instanceId]
    delete state.attachedCards[villain.instanceId]
    if (toDiscard) gainToDiscard(state, villain)
    else if (scheme.onVillainDefeated) scheme.onVillainDefeated(state, villain)
    else state.defeated.push(villain)
    for (const card of rescued) await rescueCard(state, card, ui)
    refillHq(state)
    await scheme.afterVillainDefeated?.(state, villain, ui)
    await resolveVillainDefeatHooks(state, ui, villain)
  } else {
    await removeVillainFromCity(state, cityIndex, ui, toDiscard)
    await scheme.afterVillainDefeated?.(state, villain, ui)
  }
  logEvent(state, `Defeated: ${state.cards[villain.cardId].name}`)
  await offerMindControl(state, villain, ui)
}

export async function defeatVillainFree(state: GameState, instanceId: string, ui: UiAdapter): Promise<void> {
  const index = state.city.findIndex((c) => c?.instanceId === instanceId)
  if (index === -1) throw new Error(`Złoczyńcy ${instanceId} nie ma w mieście`)

  const villain = state.city[index]!
  if (!canDefeatVillain(state, villain.cardId)) {
    throw new Error('Nie możesz teraz pokonać tego złoczyńcy (niespełniony warunek)')
  }

  // Pokonanie za darmo też uruchamia efekt Fight (anulowany Fight nie blokuje pokonania)
  const fightEffectsResolved = await resolveVillainFightEffects(state, ui, villain)
  const toDiscard = fightEffectsResolved && goesToDiscard(state, villain.cardId)

  if (state.returnVillainToCity?.instanceId === villain.instanceId) {
    const returnIndex = state.returnVillainToCity.cityIndex
    state.returnVillainToCity = undefined
    state.city[returnIndex] = villain
    logEvent(state, `Feast returned: ${state.cards[villain.cardId].name}`)
    return
  }

  await runArtifactReactions(state, ui, 'villain-defeated')
  await removeVillainFromCity(state, index, ui, toDiscard)
  await getScheme(state).afterVillainDefeated?.(state, villain, ui)
  logEvent(state, `Defeated for free: ${state.cards[villain.cardId].name}`)
  await offerMindControl(state, villain, ui)
}

async function claimTactic(state: GameState, ui: UiAdapter, mastermind: CardInstance = state.mastermind): Promise<void> {
  const tactics = mastermind.instanceId === state.mastermind.instanceId
    ? state.tactics
    : state.mastermindTactics?.[mastermind.instanceId] ?? []
  const tactic = tactics.pop()
  if (!tactic) throw new Error('Mastermind jest już pokonany')

  await ui.showInfo(tactic, `Odkryto taktykę: ${state.cards[tactic.cardId].name}`)

  const abilityId = state.mysterioTacticIds?.includes(tactic.instanceId)
    ? 'mysterio-master-strike-tactic'
    : tactic.cardId
  const ability = getCardAbility(abilityId)
  if (ability && !(await fightEffectCancelled(state, ui, tactic))) {
    await asEnemyEffect(state, () => ability(state, { self: tactic, ui }))
  }

  const returned = tactics.some((t) => t.instanceId === tactic.instanceId)
  if (!returned) state.defeated.push(tactic)

  logEvent(state, `Tactic claimed: ${state.cards[tactic.cardId].name}`)

  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)
  if (tactics.length === 0) {
    state.defeatedMastermindIds = [...(state.defeatedMastermindIds ?? []), mastermind.instanceId]
  }
  updateVictoryStatus(state)
}

function updateVictoryStatus(state: GameState): void {
  const masterminds = state.masterminds ?? [state.mastermind]
  if (masterminds.every((mastermind) => (state.defeatedMastermindIds ?? []).includes(mastermind.instanceId))) {
    state.status = 'won'
  }
}

async function resolveMastermindCaptives(
  state: GameState,
  ui: UiAdapter,
  mastermind: CardInstance = state.mastermind,
): Promise<void> {
  const captives = state.captives[mastermind.instanceId] ?? []
  const scheme = getScheme(state)
  const rescued = scheme.onCaptivesRescued?.(state, mastermind, captives) ?? captives
  delete state.captives[mastermind.instanceId]

  for (const card of rescued) await rescueCard(state, card, ui)
}

export async function fightMastermind(
  state: GameState,
  ui: UiAdapter,
  mastermindInstanceId: string = state.mastermind.instanceId,
): Promise<void> {
  assertPlaying(state)
  const mastermind = (state.masterminds ?? [state.mastermind])
    .find((candidate) => candidate.instanceId === mastermindInstanceId)
  if (!mastermind) throw new Error('Nie znaleziono Masterminda')
  const singleFight = (state.singleFightMasterminds ?? []).includes(mastermind.instanceId)
  if (!canAffordMastermindTarget(state, mastermind)) throw new Error('Nie możesz teraz walczyć z tym Mastermindem')

  // Cosmic Threat (Galactus): wybór klasy i obniżenie siły na czas tej jednej walki
  const rule = getMastermindRule(state, mastermind)
  if (rule?.beforeFight && !(await rule.beforeFight(state, ui))) return

  try {
    const strength = getEffectiveStrength(state, mastermind) ?? 0
    const mmId = mastermind.cardId
    const scheme = getScheme(state)
    const additionalCost = mastermind.instanceId === state.mastermind.instanceId
      ? scheme.mastermindFightAdditionalCost?.(state) ?? 0
      : 0
    const baseAttackAvailable = availableAttack(state, mmId)
    const totalAttackOrRecruit = state.attack + state.recruit
    const canPayBaseCost =
      baseAttackAvailable >= strength &&
      (additionalCost === 0 || totalAttackOrRecruit >= strength + additionalCost)
    if (!canPayBaseCost) {
      throw new Error(`Za mało attack: masz ${availableAttack(state, mmId)}, siła ${strength}`)
    }

    await scheme.beforeMastermindFight?.(state, ui, strength)
    await spendAttack(state, strength, ui, mmId)
    claimShardFrom(state, mastermind)
    if (singleFight) {
      state.defeatedMastermindIds = [...(state.defeatedMastermindIds ?? []), mastermind.instanceId]
      state.defeated.push(mastermind)
      addRecruit(state, state.defeatRecruitBonus ?? 0)
      for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)
      if (!rule?.captivesSurviveFight) await resolveMastermindCaptives(state, ui, mastermind)
      logEvent(state, `Mastermind defeated: ${state.cards[mastermind.cardId].name}`)
      updateVictoryStatus(state)
    } else {
      await claimTactic(state, ui, mastermind)
      if (!rule?.captivesSurviveFight) await resolveMastermindCaptives(state, ui, mastermind)
    }
  } finally {
    state.cosmicThreatReduction = 0
  }
}

export async function claimTacticFree(state: GameState, ui: UiAdapter): Promise<void> {
  await claimTactic(state, ui)
}

/** Transform Citizens Into Demons: za 2 Attack ratujesz wierzchniego Demon Goblina ze stosu obok schematu. */
export async function fightDemonGoblin(state: GameState, ui: UiAdapter): Promise<void> {
  assertPlaying(state)
  const stack = state.demonGoblins ?? []
  const goblin = stack[stack.length - 1]
  if (!goblin) throw new Error('Nie ma Demon Goblinów do pokonania')

  if (availableAttack(state, goblin.cardId) < DEMON_GOBLIN_ATTACK) {
    throw new Error(`Za mało attack: masz ${availableAttack(state, goblin.cardId)}, siła ${DEMON_GOBLIN_ATTACK}`)
  }

  await spendAttack(state, DEMON_GOBLIN_ATTACK, ui, goblin.cardId)
  stack.pop()
  logEvent(state, `Defeated: ${state.cards[goblin.cardId].name}`)

  // Demon Goblin jest Villainem, więc działają bonusy "za pokonanie Villaina" (bez lokacji, bo stoi poza miastem)
  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)

  // Uratowany jako Bystander: trafia do Victory Pool i liczy się jako "rescue" (Jean Grey itp.)
  await rescueCard(state, goblin, ui)
  await resolveVillainDefeatHooks(state, ui, goblin)
}

/** Madelyne Pryor: za Attack równy `captiveVillainAttack` ratujesz jednego z jej jeńców (Demon Goblin). */
export async function fightMastermindCaptive(state: GameState, ui: UiAdapter): Promise<void> {
  assertPlaying(state)
  const info = captiveVillainInfo(state)
  if (!info) throw new Error('Nie ma Demon Goblinów do pokonania')

  const captives = state.captives[info.mastermind.instanceId] ?? []
  const index = captives.findIndex((card) => state.cards[card.cardId].kind === 'bystander')
  const goblin = captives[index]
  if (availableAttack(state, goblin.cardId) < info.attack) {
    throw new Error(`Za mało attack: masz ${availableAttack(state, goblin.cardId)}, siła ${info.attack}`)
  }

  await spendAttack(state, info.attack, ui, goblin.cardId)
  captives.splice(index, 1)
  if (captives.length === 0) delete state.captives[info.mastermind.instanceId]
  logEvent(state, `Defeated: Demon Goblin (${state.cards[goblin.cardId].name})`)

  // Demon Goblin jest Villainem, więc działają bonusy "za pokonanie Villaina" (bez lokacji, bo stoi poza miastem)
  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)

  await rescueCard(state, goblin, ui)
  await resolveVillainDefeatHooks(state, ui, goblin)
}

/** Henchmeni leżący obok Mastermina (Build an Army of Annihilation): wierzchni jest do pokonania. */
export function nextToMastermindInfo(state: GameState): { count: number; top: CardInstance; strength: number } | undefined {
  const pile = state.mastermindHenchmen ?? []
  const top = pile[pile.length - 1]
  if (!top) return undefined
  return { count: pile.length, top, strength: getEffectiveStrength(state, top) ?? 0 }
}

export function canAffordNextToMastermind(state: GameState): boolean {
  if (state.status !== 'playing') return false
  const info = nextToMastermindInfo(state)
  return !!info && availableAttack(state, info.top.cardId) >= info.strength
}

/** Pokonuje wierzchniego henchmana leżącego obok Mastermina: jak zwykły Villain (efekt Fight, Victory Pile), ale bez miasta. */
export async function fightNextToMastermind(state: GameState, ui: UiAdapter): Promise<void> {
  assertPlaying(state)
  const info = nextToMastermindInfo(state)
  if (!info) throw new Error('Obok Mastermina nie ma henchmenów')
  const henchman = info.top
  if (availableAttack(state, henchman.cardId) < info.strength) {
    throw new Error(`Za mało attack: masz ${availableAttack(state, henchman.cardId)}, siła ${info.strength}`)
  }

  await spendAttack(state, info.strength, ui, henchman.cardId)
  state.mastermindHenchmen = (state.mastermindHenchmen ?? []).slice(0, -1)

  const fightEffectsResolved = await resolveVillainFightEffects(state, ui, henchman)
  const toDiscard = fightEffectsResolved && goesToDiscard(state, henchman.cardId)
  await runArtifactReactions(state, ui, 'villain-defeated')
  if (toDiscard) gainToDiscard(state, henchman)
  else state.defeated.push(henchman)
  logEvent(state, `Defeated: ${state.cards[henchman.cardId].name} (next to the Mastermind)`)

  addRecruit(state, state.defeatRecruitBonus ?? 0)
  for (let i = 0; i < (state.defeatRescueBonus ?? 0); i++) await rescueBystander(state, ui)

  await getScheme(state).afterVillainDefeated?.(state, henchman, ui)
  await resolveVillainDefeatHooks(state, ui, henchman)
}
